﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Zenoti.Controllers;
using System.Web;
using System.Web.Mvc;

namespace Zenoti.Tests
{
    [TestClass]
    public class SearchTest
    {
        Zenoti.Models.ZenotiSearch zenotiSeach = new Models.ZenotiSearch();
        ZenotiSearchController zenotiSearchController = new ZenotiSearchController();
        [TestMethod]
        public void ZenotiSearchTest()
        {
            ActionResult actualResult = zenotiSearchController.ZenotiSearch();
            Assert.IsNotNull(actualResult);
        }

        [TestMethod]
        public void ZenotiSearchTestByType()
        {
            ActionResult actualResult = zenotiSearchController.Search("spa");
            Assert.IsNotNull(actualResult);
        }
    }
}
