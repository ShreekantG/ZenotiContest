﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace Zenoti.Controllers
{
    public class ZenotiSearchController : Controller
    {
        //
        // GET: /ZenotiSearch/
        Zenoti.Models.ZenotiSearch zenotiSearch = new Models.ZenotiSearch();
        public ActionResult ZenotiSearch()
        {
            return View("ZenotiSearch", zenotiSearch);
        }
        [HttpPost]
        public PartialViewResult Search(string Options)
        {
            zenotiSearch.Business_type = Options;
            string file = Server.MapPath("~/zenoti_dataa014587.json");
            //deserialize JSON from file  
            string Json = System.IO.File.ReadAllText(file);
            JavaScriptSerializer ser = new JavaScriptSerializer();
            List<Models.ZenotiSearch> searchlist = ser.Deserialize<List<Models.ZenotiSearch>>(Json);
            searchlist.Any(x => x.Business_type == Options);
            var filtered = from Models.ZenotiSearch p in searchlist
                           where p.Business_type == Options
                           select p;
            return PartialView("../ZenotiSearch/SearchByType", filtered);
        }
    }
}
