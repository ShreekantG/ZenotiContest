﻿// -----------------------------------------------------------------------
// <copyright file="ZenotiSearch.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------



using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zenoti.Models
{
    public class ZenotiSearch
    {
        public string Business_name { get; set; }
        public string Business_type { get; set; }
        public string Link { get; set; }
        public string Address { get; set; }
        public string Rating { get; set; }
    }
}
